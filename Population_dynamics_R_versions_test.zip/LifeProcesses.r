# load all the phenological functions into the memory
source("PhenologicalFunctions.r")

source("UtilitiesFunctions.r")

#-----> Creation of a new super-Withe fly<-----#
make.new.super.Whitefly <- function(population,Neggs,female.percent) { 
  
  ind <- population$indiv.life.stage == not.assigned
  
  if(all(ind == FALSE)){
    stop("Unable to add more Super-Whitefly in the simulation. Increase the maximal population size")
  }
  
  if(any(ind == TRUE)){
    ind.vec = which(population$indiv.life.stage == not.assigned)
    population$indiv.life.stage[ind.vec[1]] <- egg
    if(Neggs == 1) {
      population$indiv.cohort.size[ind.vec[1]] = 1
    }else if (Neggs > 1) {
      population$indiv.cohort.size[ind.vec[1]] <- round( (Neggs*female.percent) , 0)
    }
	#print(paste0("New eggs today: ", population$indiv.cohort.size[ind[1]]))
      population$indiv.cum.degree.days[ind.vec[1]]      <- 0.0
      population$indiv.cum.sen.degree.days[ind.vec[1]]  <- 0.0
  }
  return(population)
} 

#----->mortality process<-----# 
mortality <- function(population,temperature,Cassava.Age) {
 
   # ------- > here we handle the mortality for young super White fly due to the temperature <------------ #
  
  for (life_stage in c(egg,nymph,pupa)) {
    
       # Get the total number of super-white fly at pre-reproductive
	   index.young.alive <- population$indiv.life.stage == life_stage
    
      # mortality_rate = 1 - survival_rate 
      # The cohort size must decrease due to daily temperature-dependent mortality 
	   Mortality.Rate <- 1.0 - Immature.whitefly.survival.Rate(temperature,life_stage)
      population$indiv.cohort.size[index.young.alive] <- population$indiv.cohort.size[index.young.alive]*(1.0 -  Mortality.Rate)
      # The number of individuals  must logically be an integer thus the decimals numbers are rounded-off	  
      population$indiv.cohort.size[index.young.alive] <- round(population$indiv.cohort.size[index.young.alive] , 0)
    
    
    }
  
    # ------- > here we handle the mortality for nymph super White fly due to the density <------------ #
    
           # # Get the total number of super-white fly at nymphal stage
           index.nymph.alive <- population$indiv.life.stage == nymph
		   total.nymph <- sum(population$indiv.cohort.size[index.nymph.alive])
	       Density.Nymph.Mortality.Rate <- 1.0 - Density.Dependent.Nymph.whitefly.survival.Rate(Cassava.Age,total.nymph)
           population$indiv.cohort.size[index.nymph.alive] <- population$indiv.cohort.size[index.nymph.alive]*(1.0 -  Density.Nymph.Mortality.Rate)
           # The number of individuals  must logically be an integer thus the decimals numbers are rounded-off	  
           population$indiv.cohort.size[index.nymph.alive] <- round(population$indiv.cohort.size[index.nymph.alive] , 0)
   
   
  # ------- > here we handle the mortality for old super-White fly <------------ #
  
     # Get the total number of super-white fly alive [reproductive or pre-reproductive] and the individuals who are too old
     kill.ind  <- ((population$indiv.life.stage == reproductive)|(population$indiv.life.stage == post.reproductive))&(population$indiv.cum.sen.degree.days >= 1 )
    
	 # make sure at least one individual to kill exist
      population$indiv.life.stage[kill.ind]                <- not.assigned
      population$indiv.cohort.size[kill.ind]               <- 0
      population$indiv.cum.degree.days[kill.ind]           <- 0.0
      population$indiv.cum.sen.degree.days[kill.ind]       <- 0.0
    
  # ------- > Finally,  we get rid of cohorts with zeros densities  <------------ #
  
   
    # Get the total number of super-whitefly with a cohort size < 1
     index.low.size <- population$indiv.cohort.size < 1.0 & population$indiv.life.stage == not.assigned
  
    # Is there anybody cohort with a low critical size ? 
    population$indiv.life.stage[index.low.size]          <- not.assigned # Dead !
    population$indiv.cohort.size[index.low.size]         <- 0
    population$indiv.cum.degree.days[index.low.size]     <- 0.0
    population$indiv.cum.sen.degree.days[index.low.size] <- 0.0
  	
  
  return(population)
  
}

#----->development process<-----#  
development <- function(population,temperature) { 
  
  # ------ > Accumulation of the developmental rate <----------------
  
  for (life_stage in c(egg,nymph,pupa,reproductive)) {
    
    # get pre-reproductive individuals allowed to develop
    #ind.allowed.to.develop <- (population$indiv.cum.degree.days < 1)&(population$indiv.life.stage == life_stage)
	ind.allowed.to.develop <- population$indiv.life.stage == life_stage
    
      # is there any pre-reproductive that is allowed to develop?
      #Accumulation of developmental rate : dev. rate (previous day) <- dev. rate (previous day) + dev. rate (actual day)
      population$indiv.cum.degree.days[ind.allowed.to.develop] <- Dev.rate.Accumulation(temperature,
                                                                                        population$indiv.cum.degree.days[ind.allowed.to.develop],
                                                                                        life_stage)
    
}

 # ------ > Moving to the next life stage  <----------------

 for (life_stage in c(egg,nymph,pupa,reproductive)) {	
      # Note: ready to become mature if Accumulated.Dev.Rate >= dev.Threshold (1 + variability.level); 
      # variability level = 0; the model is not individual-based
      ind.fully.dev <- (population$indiv.cum.degree.days >= 1)&(population$indiv.life.stage == life_stage) # is fully developed ?	
      
        # This will run only if there is at least one cohort is ready to get mature
        # life stage changing from the actual to the next one
        population$indiv.life.stage[ind.fully.dev]     <- life_stage + 1 
        # here we should reinitialize the accumulated Developmental rate for these new reproductive White fly
        population$indiv.cum.degree.days[ind.fully.dev] <- 0.0
      
      
    }
    

  # Moving to the old death stage [ reproductive ---> Death ; post-reproductive ---> Death ] -----> Ageing to the death (see Mortality sub-function)
  
  # get pre and post-reproductive individuals that are not yet too old
  ind.allowed.to.develop <- (population$indiv.cum.sen.degree.days < 1)&((population$indiv.life.stage == reproductive)|(population$indiv.life.stage == post.reproductive))
  # is there any reproductive that is allowed to get older ?
    #Accumulation of senescence rate : dev. rate (previous day) <- dev. rate (previous day) + dev. rate (actual day)
    population$indiv.cum.sen.degree.days[ind.allowed.to.develop] <- Dev.rate.Accumulation(temperature,
                                                                                          population$indiv.cum.sen.degree.days[ind.allowed.to.develop],
                                                                                          post.reproductive)
    
  
  
  return(population)
  
}