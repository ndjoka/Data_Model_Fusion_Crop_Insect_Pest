# This is the list of basic (atomic) functions used during the population dynamics

# Function for Development rate accumulation at each time step
Dev.rate.Accumulation <- function(temperature,Previous.Dev.rate,life_stage){  
  Previous.Dev.rate <- whitefly.developmental.rate(temperature,life_stage) + Previous.Dev.rate
  return(Previous.Dev.rate)	
}

# ---------------->  Egg developmental Rate <-------------------- 

Egg.Devel.Rate  <-function(temperature){
  
   a     <-  8.426e-03
   
   b     <-  2.119e+00
   
   Tmin  <-  1.015e+01
   
   Tmax  <-  3.802e+01  
  
  r <- a*(temperature-Tmin)/( 1 + (b^(temperature-Tmax)) )
  
  # remove possible negative values 
  ifelse( r < 0, r <- 0.0, r <- r) 
  
  # remove developmental rate higher that 1.0
  ifelse( r > 1.0, r <- 1.0, r <- r) 
  
  # remove possibility for development out of the permissive temperature range 
  Upper.Dev.Threshold <- 36.0
  
  Lower.Dev.Threshold <- 10.18476
  
  ifelse( ( temperature < Lower.Dev.Threshold ) || (temperature > Upper.Dev.Threshold ) , r <- 0.0, r <- r) 
  
  return(r)
  
}


# ---------------->  Nymph developmental Rate <-------------------- 

Nymph.Devel.Rate  <-function(temperature){
  
  p      <-    0.008053    
  
  k      <-    46.837933    
  
  delta  <-    5.894955
  
  lambda <-   -1.105855  
  
  r <- exp(p*temperature) - exp( (p*temperature) - (k-temperature)/delta) +lambda
  
  # remove possible negative values 
  ifelse( r < 0, r <- 0.0, r <- r) 
  
  # remove developmental rate higher that 1.0
  ifelse( r > 1.0, r <- 1.0, r <- r) 
  
  # remove possibility for development out of the permissive temperature range 
  Upper.Dev.Threshold <- 36.0
  
  Lower.Dev.Threshold <- 11.78421
  
  ifelse( ( temperature < Lower.Dev.Threshold ) || (temperature > Upper.Dev.Threshold ) , r <- 0.0, r <- r) 
  
  return(r)
  
}

# ---------------->  Pupa developmental Rate <-------------------- 

Pupa.Devel.Rate  <-function(temperature){
  
  p      <-    0.010529    
  
  k      <-    38.647402    
  
  delta  <-    2.057230
  
  lambda <-   -1.046143  
  
  r <- exp(p*temperature) - exp( (p*temperature) - (k-temperature)/delta) +lambda
  
  # remove possible negative values 
  ifelse( r < 0, r <- 0.0, r <- r) 
  
  # remove developmental rate higher that 1.0
  ifelse( r > 1.0, r <- 1.0, r <- r) 
  
  # remove possibility for development out of the permissive temperature range 
  Upper.Dev.Threshold <- 36.0
  
  Lower.Dev.Threshold <- 5.228402
  
  ifelse( ( temperature < Lower.Dev.Threshold ) || (temperature > Upper.Dev.Threshold ) , r <- 0.0, r <- r) 
  
  return(r)
  
}

# ---------------->  Oviposition Rate <--------------------

oviposition.Rate  <-function(temperature){
  
  c1   <-  0.075487
  
  c2   <-  0.176870
  
  k1   <-  -7.606472
  
  k2   <-  0.360645
  
  Topt <- 24.359020
  
  a1 <- 1 + exp( k1 + ( k2*temperature ) )
  
  a2 <- 1 + exp(k1 + k2* ( (2*Topt) - temperature) )
  
  r <- ( c1/a1 ) + ( c2/a2 )
  
  # remove possible negative values 
  ifelse( r < 0, r <- 0.0, r <- r) 
  
  # remove developmental rate higher that 1.0
  ifelse( r > 1.0, r <- 1.0, r <- r) 
  
  return(r)
  
}


# ---------------->  Senescence Rate <--------------------

senescence.Rate  <-function(temperature){
  
  c1   <-  0.114
  
  c2   <-  0.1248
  
  k1   <- -6.0039
  
  k2   <-  0.331102
  
  Topt <- 22.43182 
  
  a1 <- 1 + exp( k1 + ( k2*temperature ) )
  
  a2 <- 1 + exp(k1 + k2* ( (2*Topt) - temperature) )
  
  r <- ( c1/a1 ) + ( c2/a2 )
  
  # remove possible negative values 
  ifelse( r < 0, r <- 0.0, r <- r) 
  
  # remove developmental rate higher that 1.0
  ifelse( r > 1.0, r <- 1.0, r <- r) 
  
  return(r)
}

# ---------------->  Developmental Rate <--------------------

whitefly.developmental.rate <-function(temperature,life_stage){
  
  if(life_stage == egg){
     developmental.rate <- Egg.Devel.Rate (temperature) 
  }
  
  if(life_stage == nymph){
    developmental.rate <-  Nymph.Devel.Rate(temperature)
  }
  
  if(life_stage == pupa){
    developmental.rate <-  Pupa.Devel.Rate(temperature)
  }
  
  if(life_stage == reproductive){
    developmental.rate <-  oviposition.Rate(temperature)
  }
  
  if(life_stage == post.reproductive){
    developmental.rate <-  senescence.Rate(temperature)
  }
  
  return(developmental.rate)
  
}

# ---------------->  Survival Rate <--------------------

Immature.whitefly.survival.Rate <-function(temperature,life_stage){
  
  b1 <- 3.312657
  
  b2 <- -0.321430
  
  b3 <-  0.006407
  
  m <- exp( b1 + ( b2*temperature ) + ( b3*(temperature^2) ) )
  
  # remove negative values
  ifelse( m < 0 ,
          m <- 0.0,
          m <- m)

  # remove mortality higher that 100%
  ifelse( m >  1 ,
          m <- 1 ,
          m <- m)

  if(life_stage == egg){
  
  ifelse(Egg.Devel.Rate(temperature) <= 0.0,
          survival.rate <- 0.0,
          survival.rate <- (1-m)^(Egg.Devel.Rate(temperature)) )
  }
  
  if(life_stage == nymph){
    
    ifelse( Nymph.Devel.Rate (temperature) <= 0.0,
            survival.rate <- 0.0,
            survival.rate <- (1-m)^(Nymph.Devel.Rate(temperature)) )
  }
  
  if(life_stage == pupa){
    
    ifelse( Pupa.Devel.Rate (temperature) <= 0.0,
            survival.rate <- 0.0,
            survival.rate <- (1-m)^(Pupa.Devel.Rate(temperature)) )
  }
  
  return(survival.rate)
  
}

Cassava.Suitability <-function(Cassava.Age){

if(Cassava.Age < 80){
   
   P.Suitability <- 1

}else{

    P.Suitability <- exp(15.026-(2.389*log(Cassava.Age - 1)))/100

 }
 
 return(P.Suitability)

}

Density.Dependent.Nymph.whitefly.survival.Rate <-function(Cassava.Age,Nymph.Density){

        #k <- 0.001 # Good parameter
        
        #k <- 1e-01

       survival.rate <-  (1/(1 + (K.Density.Parameter*Nymph.Density)))*Cassava.Suitability(Cassava.Age)
	  
	  #survival.rate <-  (1/(1 + (K.Density.Parameter*Nymph.Density)))
	  
	  
      # remove negative values 
      ifelse( survival.rate <  0,
              survival.rate <- 0,
              survival.rate <- survival.rate )
  
       # remove survival higher that 100%
      ifelse( survival.rate >  1,
              survival.rate <- 1,
              survival.rate <- survival.rate )
			  
	#survival.rate <- 1.0		  
  
  return(survival.rate)
  
}

# ---------------->  Total eggs per females per day  <--------------------

Eggs.per.female.per.day <-function(temperature){
  
  b1 <-  18.9757

  b2 <-  -0.2894

  b3 <-  -174.1446

  total.fec <- exp( b1 +  (b2*temperature) + (b3/temperature) )
  
  # a1 <-  -0.8013  
  # 
  # a2 <-   42.2218 
  # 
  # a3 <-  -443.5485
  # 
  # total.fec <- ( a1*(temperature^2) ) + ( a2*temperature ) + a3
  
  # remove negative values
  ifelse( total.fec  <  0 ,
          total.fec  <- 0,
          total.fec  <- total.fec )
  
  ifelse( oviposition.Rate (temperature) <= 0.0,
          eggs.today <- 0.0,
          eggs.today <- total.fec*oviposition.Rate(temperature) )
  
  ifelse(eggs.today < 1,
         eggs.today <- 0.0,
         eggs.today <- round(eggs.today))
  
  return(eggs.today)
  
}