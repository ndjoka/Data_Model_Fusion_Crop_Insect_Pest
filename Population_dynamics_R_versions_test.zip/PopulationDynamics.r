ModelRunTest <- function(n.max.indiv, 
                     n.init.egg,                         # calibrate [1]
					 n.init.nymph,                       # calibrate [2]
					 n.init.pupa,                        # calibrate [3]
					 n.init.reproductive,                # calibrate [4]
					 n.init.post.reproductive,           # calibrate [5]
					 unif.init.egg.degree.days,          # calibrate [6]
					 unif.init.nymph.degree.days,        # calibrate [7]
					 unif.init.pupa.degree.days,         # calibrate [8]
					 unif.init.rep.degree.days,          # calibrate [9]
					 unif.init.adult.sen.degree.days,    # calibrate [10]
					 Min_Tmin, Max_Tmin, 
					 Min_Tmax, Max_Tmax,
                     max.number.days,
					 simulation.output){
  
  # load all the phenological functions into the memory
  source("PhenologicalFunctions.r")
  
  source("UtilitiesFunctions.r")
  
  source("LifeProcesses.r")
  
  create.global.variable()
  
 if(n.max.indiv <= 0){
     stop("There is something wrong with the maximal population size ")
 }

  # Define the Super-White fly individual-level (initial number of nymph just hatched from eggs state)
 insect.population <- create.initial.data.frame(n.max.indiv)
  
  # Initialization 
  day  <- 2
  
  # Cassava Age initialization
  Cassava.Age <- 10 
  
  # For the density-dependent survival function
 # K.Density.Parameter <<- 0.001 # good
  
  K.Density.Parameter <<- 0.004
  
  # For the density-dependent survival function
  #K.Density.Parameter <<- 0.1
  
  # Run initialization
   insect.population <-  Initial.conditions (n.max.indiv, 
                     n.init.egg,                         # calibrate [1]
					 n.init.nymph,                       # calibrate [2]
					 n.init.pupa,                        # calibrate [3]
					 n.init.reproductive,                # calibrate [4]
					 n.init.post.reproductive,           # calibrate [5]
					 unif.init.egg.degree.days,          # calibrate [6]
					 unif.init.nymph.degree.days,        # calibrate [7]
					 unif.init.pupa.degree.days,         # calibrate [8]
					 unif.init.rep.degree.days,          # calibrate [9]
					 unif.init.adult.sen.degree.days,    # calibrate [10]
					 insect.population)
  
  repeat {   
    
    #get the average temperature of today
    temperature <- ( runif(n=1,min=Min_Tmin,max=Max_Tmin) + runif(n=1,min =Min_Tmax,max=Max_Tmax) ) / 2 
	
    #temperature <- temperature + 5
    
    #print(paste0("Number of Eggs today", length(which(insect.population$indiv.life.stage == reproductive))*Eggs.per.female.per.day(temperature)))
    
	  #get reproductive individuals (females that can lay) and create a new Super-White fly
    ind.reproductive.females <- insect.population$indiv.life.stage == reproductive
    
    tot.rep <- sum(insect.population$indiv.cohort.size[ind.reproductive.females])
    
    #get reproductive individuals (females that can lay) and create a new Super-White fly
    insect.population <- make.new.super.Whitefly(insect.population, 
                                                 tot.rep*Eggs.per.female.per.day(temperature),
                                                 female.percent = 0.5)
    
    
	 # print(paste0("Current simulation day: ", day, 
	 # "  tot. female : ", length(which(insect.population$indiv.life.stage == reproductive)),
	 # "  eggs/females :", Eggs.per.female.per.day(temperature)))
	
	
    # run the Development sub-model
    insect.population <- development(insect.population,temperature)
    
     # Update  cassava age
      Cassava.Age <- Cassava.Age + 1
	
    # run the Mortality sub-model 
     insect.population <- mortality(insect.population,temperature,Cassava.Age)
    
    print(paste0("Current simulation day: ", day))
    
    # stop when all super White fly are dead
    stop.condition.1 = all(insect.population$indiv.life.stage[] == not.assigned)

    stop.condition.2 = sum(insect.population$indiv.cohort.size)==0

    if( stop.condition.1 | stop.condition.2){
         print(paste0("no one alive: ", 0))
      break
    }
    
    # here we save the cohort size (total number of individuals) at each life stages 
    simulation.output <- get.cohort.size(insect.population,simulation.output,day)

    if (day == max.number.days){
        break
    }else{
      
      day <- day + 1
    }
        
  }
   
   return(simulation.output)
   
}



#####################################################################################################################




#################################################     this must be corrected    #####################################################################


ModelRun <- function(n.max.indiv, 
                     n.init.egg,                         # calibrate [1]
					 n.init.nymph,                       # calibrate [2]
					 n.init.pupa,                        # calibrate [3]
					 n.init.reproductive,                
					 n.init.post.reproductive,           
					 unif.init.egg.degree.days,          # calibrate [4]
					 unif.init.nymph.degree.days,        # calibrate [5]
					 unif.init.pupa.degree.days,         # calibrate [6]
					 unif.init.rep.degree.days,          
					 unif.init.adult.sen.degree.days, 
                     K.parameter, 	                     # calibrate [7]				 
                     weather.data,
					 First.Day.After.Planting,
					 simulation.output){
  
  # load all the phenological functions into the memory
  source("PhenologicalFunctions.r")
  
  source("UtilitiesFunctions.r")
  
  source("LifeProcesses.r")
  
  create.global.variable()
  
 if(n.max.indiv <= 0){
     stop("Error Max.ind: There is something wrong with the maximal population size ")
 }

  # Define the Super-White fly individual-level (initial number of nymph just hatched from eggs state)
 insect.population <- create.initial.data.frame(n.max.indiv)
  
  # Cassava Age initialization
  Cassava.Age <- First.Day.After.Planting
  
  # For the density-dependent survival function
  K.Density.Parameter <<- K.parameter
    
  # Run initialization
   insect.population <-  Initial.conditions (n.max.indiv, 
                     n.init.egg,                         # calibrate [1]
					 n.init.nymph,                       # calibrate [2]
					 n.init.pupa,                        # calibrate [3]
					 n.init.reproductive,                # calibrate [4]
					 n.init.post.reproductive,           # calibrate [5]
					 unif.init.egg.degree.days,          # calibrate [6]
					 unif.init.nymph.degree.days,        # calibrate [7]
					 unif.init.pupa.degree.days,         # calibrate [8]
					 unif.init.rep.degree.days,          # calibrate [9]
					 unif.init.adult.sen.degree.days,    # calibrate [10]  
					 insect.population)
  
  max.number.days = nrow(weather.data)
  
  day <- 2
  
  repeat {   
    
       #get the average temperature of today
       temperature <- ( weather.data$tmin[day] + weather.data$tmax[day] ) / 2 
	   
	   #get reproductive individuals (females that can lay) and create a new Super-White fly
       ind.reproductive.females <- insect.population$indiv.life.stage == reproductive
    
      tot.rep <- sum(insect.population$indiv.cohort.size[ind.reproductive.females])
    
	   #get reproductive individuals (females that can lay) and create a new Super-White fly
       insect.population <- make.new.super.Whitefly(insect.population, 
	                     tot.rep*Eggs.per.female.per.day(temperature),
	 							        female.percent = 0.5)

	
    # run the Development sub-model
    insect.population <- development(insect.population,temperature)
    
	Cassava.Age <- Cassava.Age + 1
	
    # run the Mortality sub-model 
    insect.population <- mortality(insect.population,temperature,Cassava.Age)
    
    # here we save the cohort size (total number of individuals) at each life stages 
    simulation.output <- get.cohort.size(insect.population,simulation.output,day)

    if (day == max.number.days){
	
        break
		
    }else{
      
      day <- day + 1
    }
        
  }
   
   return(simulation.output)
   
}

Whitefly.population.simulation <- function(parameters,weather.data,First.Day.After.Planting){

# initial number of eggs
n.init.egg = round(parameters[1])

# initial number of nymph
n.init.nymph = round(parameters[2])

# initial number of pupa 
n.init.pupa = round(parameters[3])

# initial number of reproductive females
n.init.reproductive = 0

# initial number of post-reproductive females
n.init.post.reproductive = 0

# initial degree days of the egg
unif.init.egg.degree.days = parameters[4]

# initial degree days of the nymph
unif.init.nymph.degree.days = parameters[5]

# initial degree days of the pupa
unif.init.pupa.degree.days = parameters[6]

# initial degree days for the reproductive female
unif.init.rep.degree.days =0

# initial degree days for the old reproductive and post-reproductive females
unif.init.adult.sen.degree.days = 0

# Maximal number of individual during the simulation
n.max.indiv = 10000 # Arbitrary fixed

# Maximal number of days during the simulations
max.number.days = nrow(weather.data)

# The carrying capacity parameter
K.parameter = parameters[7]

# data to store the simulation results

simulation.output <- matrix(0, nrow = max.number.days , ncol = 4)

colnames(simulation.output) <- c("egg", "nymph" , "pupa", "adult")

simulation.output <- as.data.frame(simulation.output)

# Save the initial conditions 
simulation.output$egg[1]    <- n.init.egg

simulation.output$nymph[1]  <- n.init.nymph

simulation.output$pupa[1]   <- n.init.pupa

simulation.output$adult[1]  <- n.init.reproductive + n.init.post.reproductive

# run the model during the number of day in the weather data
simulation.output <- ModelRun (n.max.indiv, 
                     n.init.egg,                         # calibrate [1]
					 n.init.nymph,                       # calibrate [2]
					 n.init.pupa,                        # calibrate [3]
					 n.init.reproductive,                
					 n.init.post.reproductive,           
					 unif.init.egg.degree.days,          # calibrate [4]
					 unif.init.nymph.degree.days,        # calibrate [5]
					 unif.init.pupa.degree.days,         # calibrate [6]
					 unif.init.rep.degree.days,          
					 unif.init.adult.sen.degree.days, 
                     K.parameter, 	                     # calibrate [7]				 
                     weather.data,
					 First.Day.After.Planting,
					 simulation.output)
					 
  output <- matrix(0, nrow = max.number.days , ncol = 1)
  
  output[] <- simulation.output$adult[] + simulation.output$nymph[]
 
  # returning the output:
  return(output)

}