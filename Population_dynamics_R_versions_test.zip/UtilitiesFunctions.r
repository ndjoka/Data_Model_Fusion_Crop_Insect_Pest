 # This function helps to avoid define regularly the same variable used
 # in all the simulation parts
 create.global.variable <- function(){
  ####################################################################
  # I Create global variable in the system to avoid cryptic labeling # 
  ####################################################################
  
  #library(pryr)
  # pryr::object_size(1)
  # 56 B
  # pryr::object_size(-1)
  # 56 B
  # object_size("alive")
  # 112 B
  # The conclusion is it is better to use integer instead of character chain 
  # in order to save memory space in the computer. 
  # Therefore, all the state variable will be integer
  
  # '<-' for local variables and '<<-' for global variables
  
  # Super-Whitefly Life Stages
  not.assigned      <<- 0   # -----> death ! <----- the death are removed from the population
  egg               <<- 1 
  nymph             <<- 2
  pupa              <<- 3
  reproductive      <<- 4
  post.reproductive <<- 5
}

# Define the data frame that will track each Super-White fly (or cohort) separately
create.initial.data.frame <- function(n.max.indiv){ 

 insect.population <- data.frame(  indiv.life.stage          = rep(not.assigned, n.max.indiv), # The life-stage
                                   indiv.cohort.size         = rep(0, n.max.indiv),			   # The cohort size			   
                                   indiv.cum.degree.days     = rep(0.0, n.max.indiv),	       # The accumulated degree-day for development
                                   indiv.cum.sen.degree.days = rep(0.0, n.max.indiv),		   # The accumulated degree-day for ageing						   
                                   stringsAsFactors          = FALSE)
	return(insect.population)
	
}  

#This function helps to check if a vector is empty or not
vector.is.empty <- function(x) {
  return(length(x)==0)
} 

# Define the initial (cohorts) Super-White flies attributes based on the input initial conditions 
Initial.conditions <- function ( n.max.indiv,                        # input parameter [1]
                                 n.init.egg,                         # input parameter [2]
                                 n.init.nymph,                       # input parameter [3]
                                 n.init.pupa,                        # input parameter [4]
                                 n.init.reproductive,                # input parameter [5]
                                 n.init.post.reproductive,           # input parameter [6]
                                 unif.init.egg.degree.days,          # input parameter [7]
                                 unif.init.nymph.degree.days,        # input parameter [8]
                                 unif.init.pupa.degree.days,         # input parameter [9]
                                 unif.init.rep.degree.days,          # input parameter [10]
                                 unif.init.adult.sen.degree.days,    # input parameter [11]
                                 population){
  
  # if( any(c(n.init.egg, n.init.nymph, n.init.pupa, n.init.reproductive,n.init.post.reproductive) > n.max.indiv) ){
    # stop("Init. cond. Error 1: There is something wrong with the initial conditions !")
  # }
  
  # if( (n.init.egg + n.init.nymph + n.init.pupa + n.init.reproductive + n.init.post.reproductive ) > n.max.indiv ){
    # stop("Init. cond. Error 2: Error 1: There is something wrong with the initial conditions !")
  # }
  
  if( any(c(unif.init.egg.degree.days, unif.init.nymph.degree.days, unif.init.pupa.degree.days, unif.init.rep.degree.days,  unif.init.adult.sen.degree.days) > 1.0)){
    stop("Init. cond. Error 3: There is something wrong with the initial conditions !")
  }
  
  if( any(c(unif.init.egg.degree.days, unif.init.nymph.degree.days, unif.init.pupa.degree.days, unif.init.rep.degree.days,  unif.init.adult.sen.degree.days) < 0.0)){
    stop("Init. cond. Error 4: There is something wrong with the initial conditions !")
  }
  
  if( all(c(n.init.egg, n.init.nymph, n.init.pupa, n.init.reproductive,n.init.post.reproductive) == 0 )){
    stop("Init. cond. Error 5: There is something wrong with the initial conditions !")
  }
  
  if( any(c(n.init.egg, n.init.nymph, n.init.pupa, n.init.reproductive,n.init.post.reproductive) < 0 )){
    stop("Init. cond. Error 6: There is something wrong with the initial conditions !")
  }
  
   cohort <- 0
   
  if(n.init.egg>=1){
  
         cohort <- cohort + 1
  
    population$indiv.life.stage[cohort]          <- egg
    population$indiv.cohort.size[cohort]         <- n.init.egg
    population$indiv.cum.degree.days[cohort]     <- unif.init.egg.degree.days
    population$indiv.cum.sen.degree.days[cohort] <- 0.0
    
  }
  
  if(n.init.nymph >=1){
  
         cohort <- cohort + 1   
    
    population$indiv.life.stage[cohort]          <- nymph
    population$indiv.cohort.size[cohort]         <- n.init.nymph
    population$indiv.cum.degree.days[cohort]     <- unif.init.nymph.degree.days
    population$indiv.cum.sen.degree.days[cohort] <- 0.0
    
  }
  
  if(n.init.pupa >=1){
     
	     cohort <- cohort + 1 
    
    population$indiv.life.stage[cohort]          <- pupa
    population$indiv.cohort.size[cohort]         <- n.init.pupa
    population$indiv.cum.degree.days[cohort]     <- unif.init.pupa.degree.days
    population$indiv.cum.sen.degree.days[cohort] <- 0.0
    
  }
  
  if(n.init.reproductive >=1){
  
          cohort <- cohort + 1 
    
    population$indiv.life.stage[cohort]          <- reproductive
    population$indiv.cohort.size[cohort]         <- n.init.reproductive
    population$indiv.cum.degree.days[cohort]     <- unif.init.rep.degree.days
    population$indiv.cum.sen.degree.days[cohort] <- unif.init.adult.sen.degree.days
    
  }
  
  if(n.init.post.reproductive >=1){
    
          cohort <- cohort + 1
		  
    population$indiv.life.stage[cohort]          <- post.reproductive
    population$indiv.cohort.size[cohort]         <- n.init.post.reproductive
    population$indiv.cum.degree.days[cohort]     <- unif.init.adult.sen.degree.days
    population$indiv.cum.sen.degree.days[cohort] <- unif.init.adult.sen.degree.days
    
  }
  
  return(population)
  
}

# this function helps to estimate the size of the population at each life-stage
get.cohort.size <- function(population,simulation.output,day){
  
  list.stages <- colnames(simulation.output)
  
     for (life_stage in c(egg,nymph,pupa)){
       
       ind <- population$indiv.life.stage == life_stage
       
         if(!all(ind == FALSE)){
           simulation.output[ day , list.stages[life_stage] ] <- sum(population$indiv.cohort.size[ind])
         }else{
           simulation.output[ day , list.stages[life_stage] ] <- 0
         }
       
     }
  
  ind <- (population$indiv.life.stage == reproductive)|(population$indiv.life.stage == post.reproductive)
  
  if(!all(ind == FALSE)){
    simulation.output[ day , "adult" ] <- sum(population$indiv.cohort.size[ind])
  }else{
    simulation.output[ day , "adult" ] <- 0
  }
  
  return(simulation.output)

}

# this function uses the nasa power
# Sparks A (2018). “nasapower: A NASA POWER Global Meteorology, 
# Surface Solar Energy and Climatology Data Client for R.” 
# The Journal of Open Source Software, 3(30), 1035. doi:10.21105/joss.01035.

# POWER's Reference
# The data was obtained from the National Aeronautics and Space Administration (NASA) 
# Langley Research Center (LaRC) Prediction of Worldwide Energy Resource (POWER) 
# Project funded through the NASA Earth Science/Applied Science Program.

# POWER's Data Reference
# The data was obtained from the POWER Project's Hourly 2.x.x version on YYYY/MM/DD.

# Publication Notification
# The POWER Project kindly requests that users of the POWER data productions send a reference, 
# web link and/or a reprint of any published papers, reports, or a brief description of other 
# uses (for example posters, oral presentations, etc.) of the POWER data products to 
# larc-power-project@mail.nasa.gov.

get_weather_data <- function(lonlat, dates) {

require(nasapower)

wth <- as.data.frame( nasapower::get_power(
      community    = "ag",
      lonlat       = lonlat,
      pars         = c("T2M",
                       "T2M_MAX",
                       "T2M_MIN",
                       "RH2M",
                       "PRECTOTCORR"),
      dates        = dates,
      temporal_api = "daily"
) )


wth <- wth[,c(7, 6, 8, 10, 9, 11, 12)]

names(wth) <- c("YYYYMMDD", "DOY", "T2M", "T2MN", "T2MX", "RH2M", "RAIN")

return(wth)

}



# The function for fitting the model to the data
Fit.Whitefly.Model.to.Obs <- function(observed.pop.density ,
                                        day.after.planting.obs,
                                        weather.data, First.Day.After.Planting,
                                        lower, upper , 
                                        convergence, 
                                        control, 
                                        nrun, 
                                        optim.opt){
  
  
# Mullen, K., Ardia, D., Gil, D., Windover, D., Cline, J. (2011).
# DEoptim: An R package for global optimization by Differential Evolution.
# Journal of Statistical Software, 40(6), 1-26.
# https://doi.org//10.18637/jss.v040.i06
  
  require(DEoptim) # The genetic algorithm package (contains the "DEoptim" function)
  
  # Important comments and description of the function #
  
  # X.obs.data: vector of x - entry of the data (e.g., time, temperature ...etc), 
  # y.obs.data: vector of observed data (y - entry of the data), 
  # lower: vector of the lower limits of feasible solutions of model parameters
  # upper: vector of the upper limits of feasible solutions of model parameters. 
  # convergence:  (model parameters and the goodness of fit) that can make the convergence item (rmse, rss, chi.sq) to be lowest. 
  
  # rmse    = root mean squared error
  # rss     = root of the sum of the squared root
  # chis.sq = chi-squared
  
  # optim.opt: There is an option of ‘optim.opt=TRUE’, which means that using the fitted parameters of 
  # the ‘DEoptim’ function as the initial values to carry out an additional optimization based on the ‘optim’ function. 
  # If the fitted parameters using the ‘DEoptim’ function are the same as 
  # those using the ‘optim’ function, and the fitted parameters do not exceed 
  # the predetermined lower and upper values of parameters, 
  # then the global optimization for searching the objective parameters are achieved. 
  
  # Note:
  # Otherwise, to adjust the range of the lower and upper values of input parameters, 
  # and also enhance the values of 'NP' and 'itermax'. 
  
  # If the lower and upper values are feasible, 
  # we only need increase 'NP' and 'itermax' both to 3000 and 
  # can get the global optimization for searching the objective parameters. 
  
  # The output variables have ‘mat’, ‘par.tab’ and ‘par’. 
  # The variable of ‘mat’ saves the n times differential evolution calculations 
  # (that is controlled by the option of nrun). When nrun=1, mat is an array. 
  
  # The output variable of par.tab is a data frame that saves the final estimates 
  #(model parameters and the goodness of fit) that can make the convergence item (rmse, rss, chi.sq) to be lowest. 
  #The default of convergence item is the residual sum of squares (namely rss). 
  #The output variable of par is the final estimates on the model parameters.  
  
  
  
  # Developing time: early January, 2024
  # Developer: Frank T. Ndjomatchoua (Dr.)
  # E-mail: ftndjomatchoua@gmail.com 
  
  if(nrun <= 0){
    stop("nrum must be a positive integer.")  
  }
  
  nrun <- round(nrun)
  
  if( !(convergence %in% c("chi.sq", "rss", "rmse")) ){
    stop("Convergence must be chi.sq or rss or rmse.")
  }
  
  myfun <- function(P2) {
  
      source("populationDynamics.r")
    
      predictions <- Whitefly.population.simulation(P2,weather.data,First.Day.After.Planting)
      
     Est <- predictions[day.after.planting.obs] # Get the estimated values from simulation only at day of observation
	
     Obs <- observed.pop.density
	
	# Normalize the observed and estimated data 
	#Est <- Normalize_Population_Data(Est)
	
	#Obs <- Normalize_Population_Data(Obs)
    
    if(convergence == "chi.sq"){
      
      temp <- abs(sum(((Obs-Est)^2)/Est))
      
    }
    
    if(convergence == "rss"){
      
      temp <- sum((Est-Obs)^2)
      
    }
    
    if(convergence == "rmse"){
      
      temp <- sqrt(sum((Obs-Est)^2)/length(Obs))
      
    }
    
    return(temp)
    
  } 
  
  if(length(lower)!=length(upper)){
    
    stop("The size of input parameter range does not match !")
    
  }
  
  mat  <- matrix(NA, nrow=nrun, ncol=length(lower)+4)
  
  for(i in 1:nrun){
    
    if(nrun > 1){
      Sys.sleep(.005)
      cat(i, paste(" of ", nrun, "\r", sep="")) # print the evolotution of G. algorithm in the R console            
      flush.console()               
      if (i %% nrun == 0) cat("\n")
    }   
    
    results <- DEoptim(myfun, lower=lower, upper=upper, control=control )  
    
    # P3: the estimates of parameters using the 'DEoptim' genetic - algorithm (GA)
       P3   <- as.numeric(results$optim$bestmem)      
    
    # get the prediction results based on the newly optimized data 
      sim.output <- Whitefly.population.simulation(P3,weather.data,First.Day.After.Planting)
	
	  Est3 <- sim.output[day.after.planting.obs] # Get the estimated values from simulation only at day of observation
	
    #Est3 <- Est3[-1] # remove the first simulated data 
	
    #Obs     <- observed.pop.density[-1]
	
        Obs  <- observed.pop.density
    
    # Normalize the observed and estimated data 
	# Est3 <- Normalize_Population_Data(Est3)
	
	# Obs <- Normalize_Population_Data(Obs)
	
    rss     <- sum((Est3 - Obs)^2)
    
    chi.sq  <- abs(sum((Est3 - Obs)^2/Est3))
    
    rmse    <- sqrt(sum((Est3 - Obs)^2)/length(Obs))
    
    R.sq    <- 1.0 - (sum((Est3 - Obs)^2)/sum((Obs-mean(Obs))^2)) 
    
    mat[i, ] <- c(P3[1], P3[2], P3[3], P3[4], P3[5], P3[6], P3[7], rss, rmse, chi.sq, R.sq)
  }
  
  rss    <- length(lower) +  1 # we could use the vector "upper" too!
  
  rmse   <- length(lower) +  2
  
  chi.sq <- length(lower) +  3
  
  R.sq   <- length(lower) +  4
  
  # the integer "index" bellow contains the parameter
  # optimally (having the lowest convergence criterion) convergent  
  if( convergence=="rss" ){
    index  <- which(mat[, rss] == min(mat[, length(lower)+1]))[1]
  }
  
  if( convergence=="rmse" ){
    index  <- which(mat[, rmse] == min(mat[, length(lower)+2]))[1]
  }
  
  if( convergence=="chi.sq" ){
    index  <- which(mat[, chi.sq] == min(mat[, length(lower)+3]))[1]
  }
  
  M    <- mat[index, ]  
  
  # P4: best parameters values after the "nrun" of "DEoptim" genetic - algorithm
  P4      <- M[1:length(lower)]
  
  if(optim.opt == "TRUE" | optim.opt =="T" | optim.opt == "True" | optim.opt == "true"){
    res     <- optim(M[1:length(lower)], myfun)
    P4      <- res$par[1:length(lower)]
  }
   
  sim.output <- Whitefly.population.simulation(P4,weather.data,First.Day.After.Planting)
  
  n.init.egg = P4[1]
  n.init.nymph = P4[2]
  n.init.pupa = P4[3]
  unif.init.egg.degree.days = P4[4]
  unif.init.nymph.degree.days = P4[5]
  unif.init.pupa.degree.days = P4[6]
  K.parameter = P4[7]

  Est4 <- sim.output[day.after.planting.obs] # Get the estimated values from simulation only at day of observation
	
  #Est4 <- Est4[-1] # remove the first simulated data 
  
  #Obs    <- observed.pop.density[-1]
   
   Obs    <- observed.pop.density
  
  # Normalize the observed and estimated data 
  #Est4 <- Normalize_Population_Data(Est4)
	
  #Obs <-  Normalize_Population_Data(Obs)
  
  rss     <- sum((Est4 - Obs)^2)
  
  chi.sq  <- abs(sum((Est4 - Obs)^2/Est4))
  
  rmse    <- sqrt(sum((Est4 - Obs)^2)/length(Obs))
  
  R.sq    <- 1 - sum((Est4 - Obs)^2)/sum((Obs-mean(Obs))^2)
  
  colnames(mat) <- c( "n.init.egg" ,                    #parameter[1]
                      "n.init.nymph",                   #parameter[2]
					  "n.init.pupa",                    #parameter[3]
                      "unif.init.egg.degree.days",      #parameter[4]
                      "unif.init.nymph.degree.days",    #parameter[5]
                      "unif.init.pupa.degree.days",     #parameter[6]
					  "K.parameter",                    #parameter[7]
                      "rss", "rmse", "chi.sq", "R.sq" ) #convergence parameters
  
  par.tab <- data.frame( n.init.egg    = n.init.egg ,
                         n.init.nymph  = n.init.nymph ,
                         n.init.pupa   = n.init.pupa ,
                         unif.init.egg.degree.days = unif.init.egg.degree.days ,
                         unif.init.nymph.degree.days = unif.init.nymph.degree.days ,
                         unif.init.pupa.degree.days = unif.init.pupa.degree.days , 
						 K.parameter =  K.parameter,
                         rss=rss, rmse=rmse, chi.sq=chi.sq, R.sq=R.sq)
  
  return(list( mat=mat, par.tab=par.tab, par=P4 )) 
  
}

# This function will help to normalize the data
Normalize_Population_Data <- function(data){
  data <- (cumsum(data)/max(cumsum(data)))*100
  data <- sort(data)
 return(data)
}

# This function will help to normalize the data between 0 and 1
Normalize_Population_Data_2 <- function(data){
  if(max(data) - min(data) == 0)stop("something wrong with the data!")
  data <- ((data-min(data))/(max(data)-min(data)))*100
  return(data)
}