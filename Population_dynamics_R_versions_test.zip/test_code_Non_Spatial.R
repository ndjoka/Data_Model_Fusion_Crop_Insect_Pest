#clear the memory
rm(list=ls())

# #clear the console
cat("\014")

#To make sure that the result will be repeated despite the stochasticity
set.seed(161803398)

# Maximal number of individual during the simulation
n.max.indiv = 10000

# initial number of eggs
n.init.egg = 1

# initial number of nymph
n.init.nymph = 1

# initial number of pupa 
n.init.pupa = 1

# initial number of reproductive females
n.init.reproductive = 1

# initial number of post-reproductive females
n.init.post.reproductive = 1

# initial degree days of the egg
unif.init.egg.degree.days = 0.01

# initial degree days of the nymph
unif.init.nymph.degree.days = 0.01

# initial degree days of the pupa
unif.init.pupa.degree.days = 0.01

# initial degree days for the reproductive female
unif.init.rep.degree.days = 0.01

# initial degree days for the old reproductive and post-reproductive females
unif.init.adult.sen.degree.days = 0.001

# # temperature treatment
 Min_Tmin <- 12 # ok
 Max_Tmin <- 20 # ok
# 
 Min_Tmax <<- 20 # ok
 Max_Tmax <<- 35 # ok
# # ----> <------------


# temperature treatment
# Min_Tmin <- 30 # OK
# Max_Tmin <- 30 # OK
# 
# Min_Tmax <<- 30 # OK
# Max_Tmax <<- 30 # OK
# # ----> <------------


# worst case scenarios !
#Min_Tmin <- 5
#Max_Tmin <- 10

#Min_Tmax <- 15
#Max_Tmax <- 20

# temperature treatment
#Min_Tmin <- 20 # OK
#Max_Tmin <- 35 # OK

#Min_Tmax <<- 35 # OK
#Max_Tmax <<- 40 # OK

source("populationDynamics.r")

# Maximal number of days during the simulations
max.number.days <- 150

# data to store the simulation results

simulation.output <- matrix(0, nrow = max.number.days , ncol = 4)

colnames(simulation.output) <- c("egg", "nymph" , "pupa", "adult")

simulation.output <- as.data.frame(simulation.output)

# Save the initial conditions 
simulation.output$egg[1]    <- n.init.egg

simulation.output$nymph[1]  <- n.init.nymph

simulation.output$pupa[1]   <- n.init.pupa

simulation.output$adult[1]  <- n.init.reproductive + n.init.post.reproductive

# Run the simulation model
simulation.output <- ModelRunTest (n.max.indiv, 
           n.init.egg,                         # calibrate [1]
					 n.init.nymph,                       # calibrate [2]
					 n.init.pupa,                        # calibrate [3]
					 n.init.reproductive,                # calibrate [4]
					 n.init.post.reproductive,           # calibrate [5]
					 unif.init.egg.degree.days,          # calibrate [6]
					 unif.init.nymph.degree.days,        # calibrate [7]
					 unif.init.pupa.degree.days,         # calibrate [8]
					 unif.init.rep.degree.days,          # calibrate [9]
					 unif.init.adult.sen.degree.days,    # calibrate [10]
					 Min_Tmin, Max_Tmin, 
					 Min_Tmax, Max_Tmax,
           max.number.days,
					 simulation.output)

y.egg    <- as.numeric(simulation.output$egg)

y.nymph  <- as.numeric(simulation.output$nymph)

y.pupa   <- as.numeric(simulation.output$pupa)

y.adult  <- as.numeric(simulation.output$adult)
   
x.egg   <- 1:length(y.egg)

x.nymph <- 1:length(y.nymph)

x.pupa  <- 1:length(y.pupa)

x.adult <- 1:length(y.adult)

ymx <- max( max(y.egg) , max(y.nymph) , max(y.pupa) , max(y.adult) )
library(latex2exp)

#Default margins of R plot
bottom <- 5.1
left   <- 4.1
top    <- 4.1
right  <- 2.1
  
par(mar = c(bottom, left + 0.7, top, right) )#increase left margin with 0.7
  
plot( x.egg,
      y.egg,
      lty=1,
      type="l",
      lwd = 3,
      xlab= "Days",
      ylab= "Pop. Density (#)",
      xlim =c(0,max.number.days + 10),
      ylim =c(0, ymx + 200),
      col="blue",
      #pch = 16,
      #cex=2,
      cex.lab=2,
      #cex.axis=1.5,
      frame.plot = FALSE,
      axes=FALSE,
      font.lab=2)

lines(x.nymph, y.nymph , col = "black", lty = 2, lwd=3 )

lines(x.pupa, y.pupa , col = "red"  , lty = 3, lwd=3 )

lines(x.adult, y.adult , col = "green" , lty = 4, lwd=3 )
  
axis(side = 1, lwd = 3 ,cex.lab=1.5, cex.axis =2, font.lab=2)

axis(side = 2, lwd = 3 ,cex.lab=1.5, cex.axis =2, font.lab=2)




#inset=c(0,1) - moves the legend by fraction of plot region in (x,y) directions. 

#In this case the legend is at "bottomright" position. It is moved by 0 plotting regions in x direction (so stays at "right") 
#and by 1 plotting region in y direction (from bottom to top). And it so happens that it appears right above the plot.

#xpd=TRUE - let's the legend appear outside of plotting region.

#horiz=TRUE - instructs to produce a horizontal legend.

#bty="n" - a style detail to get rid of legend bounding box.

####### Good ! #########################################################

legend("bottomright",
       inset     = c(0,1),
       xpd       = TRUE,
       border    = "black",
       legend    = c("Egg","Nymph","Pupa","Adult"),
       col       = c("blue","black","red","green"),
       #pch       = c(1,2,3,4),
       lty       = c(1,2,3,4),
       lwd       = c(3,3,3,3),
       cex       = 1.5,
       #title     = "Life Stages" ,
       horiz     =  TRUE,
       bty       = "n",
       #bg        ='lightgray',
       text.font = 2)

#print(y.adult[100])

# Same applies when adding legend to the side:
#   
#   par(mar=c(5,4,2,6))
# plot(1:3, rnorm(3), pch = 1, lty = 1, type = "o", ylim=c(-2,2))
# lines(1:3, rnorm(3), pch = 2, lty = 2, type="o")
# 
# legend("topleft", c("group A", "group B"), pch=c(1,2), lty=c(1,2),
#        inset=c(1,0), xpd=TRUE, bty="n"
# )
# Here we simply adjusted legend positions and added additional margin space to the right side of the plot. Result:

plot(x.egg,y.adult+y.nymph)

#plot(x.egg,y.adult)
