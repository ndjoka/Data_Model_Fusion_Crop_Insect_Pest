# remove the data from the memory
rm(list=ls())
#clear the console
cat("\014")

library(raster)
library(countrycode)
library(sf)
library(ggplot2)
library(tidyr)
library(latex2exp)
library(RColorBrewer)
library(latticeExtra)
library(rnaturalearth)
library(rnaturalearthdata)
library(rnaturalearthhires)
library(rnaturalearth)
library(viridis)
library(raster)
library(countrycode)
library(sf)
library(renv)
library(maptools)
library(tidyverse)
library(terra)
library(geodata)
library(gtools)
library(tabularaster)
library(tibble)
library(tidyr)

#renv::init(repos = "https://packagemanager.posit.co/cran/2023-10-13")
#install.packages("maptools")
#https://cran.r-project.org/bin/windows/Rtools/rtools44/files/rtools44-aarch64-6335-6327.exe
#library(devtools)
#devtools::install_github("ropensci/rnaturalearthhires")




# -----------> Past Climate data <-------------

######################################################
#  Step 1:     Import all the cropped data at once  ##
######################################################

#The folder where the files are located 
clim_list_Tmin <- list.files("past_geospatial/Africa/tempMin",
                             pattern = ".tif$", 
                             full.names = T)  

#order files names my ascending order
clim_list_Tmin <- gtools::mixedsort(clim_list_Tmin)

#stacking the bioclim variables to process them at one go
clim_Tmin <- raster::stack(clim_list_Tmin)

#The folder where the files are located 
clim_list_Tmax <- list.files("past_geospatial/Africa/tempMax",
                             pattern = ".tif$", 
                             full.names = T)  

#order files names my ascending order
clim_list_Tmax <- gtools::mixedsort(clim_list_Tmax)

# stacking the bioclim variables to process them at one go
clim_Tmax <- raster::stack(clim_list_Tmax)



# index of the cells in the raster with no "NA"
df <- tabularaster::as_tibble(clim_Tmax[[1]], # a RasterLayer, RasterStack or RasterBrick  
                              cell = TRUE, #logical to include explicit cell number
                              dim = nlayers(clim_Tmax[[1]]) > 1L, # logical to include slice index
                              value = TRUE, # logical to return the values as a column or not
                              split_date = FALSE, #logical to split date into components
                              xy = FALSE) #logical to include the x and y centre coordinate of each cell 

df <- as.data.frame(df)

#remove rows with na
df <-  tidyr::drop_na(df)

# Get the indexes for the land
cellindex.of.land <- df$cellindex

# get the total number of cells 
total.land.cell <- as.numeric(length(df$cellindex))

Tmin <- as.data.frame(clim_Tmin[[1:12]][cellindex.of.land])

Tmax <- as.data.frame(clim_Tmax[[1:12]][cellindex.of.land])

#fill the data frame to save the data 
weather.data.save  <- matrix(0, nrow = total.land.cell, ncol= 25 )

weather.data.save <- as.data.frame(weather.data.save)

# save the cell index in the first columnn

weather.data.save[ 1:total.land.cell , 1] <- cellindex.of.land [1:total.land.cell]

# save Tmin at each cell
weather.data.save[ 1:total.land.cell , 2:13  ] <- Tmin[  1:total.land.cell , 1:12 ]

# save Tmax at each cell
weather.data.save[ 1:total.land.cell , 14:25 ] <- Tmax[  1:total.land.cell , 1:12 ]


# save the experiment 1 temperature data to drive the model
write.table(weather.data.save, 
            file = "past_Africa.txt", sep = "\t",
            row.names = FALSE, col.names = FALSE)





# -----------> Future Climate data <-------------


######################################################
#  Step 1:     Import all the cropped data at once  ##
######################################################

#The folder where the files are located 
clim_list_Tmin <- list.files("future_geospatial/Africa/tempMin",
                             pattern = ".tif$", 
                             full.names = T)  

#order files names my ascending order
clim_list_Tmin <- gtools::mixedsort(clim_list_Tmin)

#stacking the bioclim variables to process them at one go
clim_Tmin <- raster::stack(clim_list_Tmin)

#The folder where the files are located 
clim_list_Tmax <- list.files("future_geospatial/Africa/tempMax",
                             pattern = ".tif$", 
                             full.names = T)  

#order files names my ascending order
clim_list_Tmax <- gtools::mixedsort(clim_list_Tmax)

# stacking the bioclim variables to process them at one go
clim_Tmax <- raster::stack(clim_list_Tmax)



# index of the cells in the raster with no "NA"
df <- tabularaster::as_tibble(clim_Tmax[[1]], # a RasterLayer, RasterStack or RasterBrick  
                              cell = TRUE, #logical to include explicit cell number
                              dim = nlayers(clim_Tmax[[1]]) > 1L, # logical to include slice index
                              value = TRUE, # logical to return the values as a column or not
                              split_date = FALSE, #logical to split date into components
                              xy = FALSE) #logical to include the x and y centre coordinate of each cell 

df <- as.data.frame(df)

#remove rows with na
df <-  tidyr::drop_na(df)

# Get the indexes for the land
cellindex.of.land <- df$cellindex

# get the total number of cells 
total.land.cell <- as.numeric(length(df$cellindex))

Tmin <- as.data.frame(clim_Tmin[[1:12]][cellindex.of.land])

Tmax <- as.data.frame(clim_Tmax[[1:12]][cellindex.of.land])

#fill the data frame to save the data 
weather.data.save  <- matrix(0, nrow = total.land.cell, ncol= 25 )

weather.data.save <- as.data.frame(weather.data.save)

# save the cell index in the first columnn

weather.data.save[ 1:total.land.cell , 1] <- cellindex.of.land [1:total.land.cell]

# save Tmin at each cell
weather.data.save[ 1:total.land.cell , 2:13  ] <- Tmin[  1:total.land.cell , 1:12 ]

# save Tmax at each cell
weather.data.save[ 1:total.land.cell , 14:25 ] <- Tmax[  1:total.land.cell , 1:12 ]


# save the experiment 1 temperature data to drive the model
write.table(weather.data.save, 
            file = "future_Africa.txt", sep = "\t",
            row.names = FALSE, col.names = FALSE)
