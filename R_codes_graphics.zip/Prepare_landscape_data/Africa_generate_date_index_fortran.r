#clear the memory
rm(list=ls())

#clear the console
cat("\014")

#########################################################
#                                                       #
#   Generation of the sequence for the day of the year  #
#   and  the corresponding month The adult data         #
#                                                       #
#########################################################

get_dates <- function(start.date, end.date){
  
  # we load the r packages to conveniently handle the sequences of dates 
  library(lubridate)
  
  library(dplyr)
  
  start.date <- lubridate::dmy(start.date)
  
  end.date  <-  lubridate::dmy(end.date)  
  
  # we generate a sequence of date from 1 January to 31st December
  # We pick the year having 365 days (e.g., the year 2014)
  date <- seq(as.Date(start.date), as.Date(end.date), "days")    
  
  # The list of the day of the year
  day = lubridate::day(date)
  
  # Extract the month
  months <- format(date, "%m")
  
  months <- as.numeric(months)
  
  #header name for the data frame 
  names.data <- c("day.index","dom", "doy", "lom", "moy")
  
  #fill the data frame with NA
  data.temp.day  <- array(NA, dim=c(length(day), length(names.data)))
  
  data.temp.day <- as.data.frame(data.temp.day)
  
  colnames(data.temp.day) <- names.data
  
  # fill the day of the month 
  data.temp.day$dom <- day
  
  # fill the month of the year 
  data.temp.day$moy <- months
  
  # Extract the year
  year <- format(start.date, "%Y")
  
  first.day.of.the.year <- paste(paste0("01 ", "Jan ", year))
  
  first.day.of.the.year <-lubridate::dmy(first.day.of.the.year) 
  
  date.before <- seq(as.Date(first.day.of.the.year), as.Date(start.date), "days") 
  
  first.doy <- length(date.before)
  
  data.temp.day$doy[1] <- first.doy
  
  # Now we have to fill the day of the year 
  for (i in 2:nrow(data.temp.day)) {
    
    if( (data.temp.day$moy[i-1] <= 12)  &&  (data.temp.day$moy[i] <= 12) ){
      
      data.temp.day$doy[i] <- data.temp.day$doy[i-1] + 1 
      
    }
    
    if( (data.temp.day$moy[i]==1)  && (data.temp.day$dom[i]==1) &&  (data.temp.day$doy[i-1] >=364 )  ) {
      
      data.temp.day$doy[i] <- 1 
      
    }
    
  }
  

  # Now we have to fill the length for each month
  for (month in 1:12) {
    
    index <- which(data.temp.day$moy  == month )
    
    data.temp.day$lom[index] <-  max(data.temp.day$dom[index])
    
  }
  
  
  data.temp.day$day.index[] <- 1:nrow(data.temp.day)
  
  return (data.temp.day)
  
}


start.date = "01 Jan 2020" 

end.date   = "31 Dec 2022"


date.matrix <-  get_dates(start.date, end.date)


# save the Adult data for the 2015 season
write.table(date.matrix, 
            file = "date_index.txt", sep = "\t",
            row.names = FALSE, 
            col.names = FALSE)
