# remove all variables in the memory
rm(list=ls())
#clear the console
cat("\014")

library(raster)
library(countrycode)
library(sf)
library(ggplot2)
library(tidyr)
library(latex2exp)
library(RColorBrewer)
library(latticeExtra)
library(rnaturalearth)
library(rnaturalearthdata)
library(rnaturalearthhires)
library(rnaturalearth)
library(viridis)
library(raster)
library(countrycode)
library(sf)
library(renv)
library(maptools)
library(tidyverse)
library(terra)
library(geodata)

#renv::init(repos = "https://packagemanager.posit.co/cran/2023-10-13")
#install.packages("maptools")
#https://cran.r-project.org/bin/windows/Rtools/rtools44/files/rtools44-aarch64-6335-6327.exe
#library(devtools)
#devtools::install_github("ropensci/rnaturalearthhires")


# here we import first the landscape for cassava in africa
host_Africa_rescaled <- raster("Land_cassava_raster_Africa_25KM.tif")

host_Africa_rescaled 

# Take only the cells with cassava cropping greater than 0
SPDF <- raster::rasterToPolygons(host_Africa_rescaled, fun=function(x){x>0 & x<=1} , n=4, na.rm=TRUE ) 


# set the scale
resolution.pixel <- 25 # be carefull !

#################################
#Step 1 : past climate scenario #
#################################


dir_tmax <- as.character("D:/climate data/Tmax_CHELSA_2013")

dir_tmin <- as.character("D:/climate data/Tmin_CHELSA_2013")

filename_prexi_1_to_9_tmin <- as.character("/CHELSA_tmin10_0")

filename_prexi_10_to_12_tmin <- as.character("/CHELSA_tmin10_")

filename_prexi_1_to_9_tmax <- as.character("/CHELSA_tmax10_0")

filename_prexi_10_to_12_tmax <- as.character("/CHELSA_tmax10_")

suffix <- as.character("_1979-2013_V1.2_land")

# initialization of an empty vector for Tmin and Tmax
names.Tmin <- rep("",times = 12)

names.Tmax <- rep("",times = 12)

for(i in 1:12){
  
  if(i <= 9) {
    names.Tmin[i] <-  as.character(paste(dir_tmin,filename_prexi_1_to_9_tmin, i , suffix,sep=""))
    names.Tmax[i] <-  as.character(paste(dir_tmax,filename_prexi_1_to_9_tmax, i , suffix,sep=""))
  }
  
  if(i > 9) {
    names.Tmin[i] <-  as.character(paste(dir_tmin,filename_prexi_10_to_12_tmin, i , suffix,sep=""))
    names.Tmax[i] <-  as.character(paste(dir_tmax,filename_prexi_10_to_12_tmax, i , suffix,sep=""))
  }
  
}



#start, create folders in your workspace:
if (!dir.exists("past_geospatial"))dir.create(path = "past_geospatial")

#start, create folders in your workspace for Africa
if (!dir.exists("past_geospatial/Africa"))dir.create(path = "past_geospatial/Africa")

#start, create folders in your workspace for Tmin
if (!dir.exists("past_geospatial/Afica/tempMin"))dir.create(path = "past_geospatial/Africa/tempMin")

#start, create folders in your workspace for Tmax
if (!dir.exists("past_geospatial/Africa/tempMax"))dir.create(path = "past_geospatial/Africa/tempMax")

dir_tmin <- as.character("past_geospatial/Africa/tempMin")

dir_tmax <- as.character("past_geospatial/Africa/tempMax")

name_of_the_month <- c('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')

#data(wrld_simpl)
#SPDF <- subset(wrld_simpl, NAME=="Africa")

for(i in 1:12){
  
  # load raster in an R object called 'rast'
  rastmin0 <- raster(paste(names.Tmin[i],".tif",sep = ""))
  rastmax0 <- raster(paste(names.Tmax[i],".tif",sep = ""))
  
  ## crop
  rastmin1  <- raster::crop(rastmin0 , extent(SPDF))
  rastmax1  <- raster::crop(rastmax0 , extent(SPDF))
  
  # Rescale the original raster
  rastmin2 <- raster::aggregate(rastmin1, fact = resolution.pixel, expand=TRUE, fun=mean, na.rm=TRUE)
  rastmax2 <- raster::aggregate(rastmax1, fact = resolution.pixel, expand=TRUE, fun=mean, na.rm=TRUE)
  
  rastmin  <- raster::mask(rastmin2, SPDF)
  rastmax  <- raster::mask(rastmax2, SPDF)
  
  # make the memroy free
  rm(rastmin1)
  rm(rastmin2)
  rm(rastmax1)
  rm(rastmax2)
  
  # 
  rastmin <- setMinMax(rastmin)
  rastmax <- setMinMax(rastmax)
  
  # be aware that the original data are multiplied by 10 to reduce decimals and save the memory
  rastmin <- rastmin/10
  rastmax <- rastmax/10
  
  #spatial projection
  projection(rastmin) <- crs(rastmin0) # May not be needed
  projection(rastmax) <- crs(rastmax0) # May not be needed
  
  # make the memroy free
  rm(rastmax0)
  rm(rastmin0)
  
  directory.tmin <- paste(dir_tmin,"/tmin",as.character(i),".tif", sep = "")
  directory.tmax <- paste(dir_tmax,"/tmax",as.character(i),".tif", sep = "")
  
  # save raster
  terra::writeRaster(rastmin,directory.tmin, filetype = "GTiff", overwrite = T)
  terra::writeRaster(rastmax,directory.tmax, filetype = "GTiff", overwrite = T)
  
  #data quality check!
  
  
  print(paste0("creation of min max past temperature raster for the month ",name_of_the_month[i]," completed"))
  
}


###################################
#Step 2 : future climate scenario #
###################################


dir_tmax <- as.character("D:/climate data/Tmax_CHELSA_2050")

dir_tmin <- as.character("D:/climate data/Tmin_CHELSA_2050")

filename_prefix_tmin <- as.character("/CHELSA_tasmin_mon_ACCESS1-0_rcp85_r1i1p1_g025.nc_")

filename_prefix_tmax <- as.character("/CHELSA_tasmax_mon_ACCESS1-0_rcp85_r1i1p1_g025.nc_")

suffix <- as.character("_2041-2060_V1.2")

# initialization of an empty vector for Tmin and Tmax
names.Tmin <- rep("",times = 12)

names.Tmax <- rep("",times = 12)

for(i in 1:12){
  
  names.Tmin[i] <-  as.character(paste(dir_tmin,filename_prefix_tmin, i , suffix,sep=""))
  names.Tmax[i] <-  as.character(paste(dir_tmax,filename_prefix_tmax, i , suffix,sep=""))
  
}



#start, create folders in your workspace:
if (!dir.exists("future_geospatial"))dir.create(path = "future_geospatial")

#start, create folders in your workspace for Africa
if (!dir.exists("future_geospatial/Africa"))dir.create(path = "future_geospatial/Africa")

#start, create folders in your workspace for Tmin
if (!dir.exists("future_geospatial/Africa/tempMin"))dir.create(path = "future_geospatial/Africa/tempMin")

#start, create folders in your workspace for Tmax
if (!dir.exists("future_geospatial/Africa/tempMax"))dir.create(path = "future_geospatial/Africa/tempMax")

dir_tmin <- as.character("future_geospatial/Africa/tempMin")

dir_tmax <- as.character("future_geospatial/Africa/tempMax")

name_of_the_month <- c('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')

#data(wrld_simpl)
#SPDF <- subset(wrld_simpl, NAME=="Africa")

for(i in 1:12){
  
  # load raster in an R object called 'rast'
  rastmin0 <- raster(paste(names.Tmin[i],".tif",sep = ""))
  rastmax0 <- raster(paste(names.Tmax[i],".tif",sep = ""))
  
  ## crop
  rastmin1  <- raster::crop(rastmin0 , extent(SPDF))
  rastmax1  <- raster::crop(rastmax0 , extent(SPDF))
  
  # Rescale the original raster
  rastmin2 <- raster::aggregate(rastmin1, fact = resolution.pixel, expand=TRUE, fun=mean, na.rm=TRUE)
  rastmax2 <- raster::aggregate(rastmax1, fact = resolution.pixel, expand=TRUE, fun=mean, na.rm=TRUE)
  
  rastmin  <- raster::mask(rastmin2, SPDF)
  rastmax  <- raster::mask(rastmax2, SPDF)
  
  # make the memroy free
  rm(rastmin1)
  rm(rastmin2)
  rm(rastmax1)
  rm(rastmax2)
  
  # 
  rastmin <- setMinMax(rastmin)
  rastmax <- setMinMax(rastmax)
  
  # be aware that the original data are multiplied by 10 to reduce decimals and save the memory
  rastmin <- rastmin/10
  rastmax <- rastmax/10
  
  #spatial projection
  projection(rastmin) <- crs(rastmin0) # May not be needed
  projection(rastmax) <- crs(rastmax0) # May not be needed
  
  # make the memroy free
  rm(rastmax0)
  rm(rastmin0)
  
  directory.tmin <- paste(dir_tmin,"/tmin",as.character(i),".tif", sep = "")
  directory.tmax <- paste(dir_tmax,"/tmax",as.character(i),".tif", sep = "")
  
  # save raster
  terra::writeRaster(rastmin,directory.tmin, filetype = "GTiff", overwrite = T)
  terra::writeRaster(rastmax,directory.tmax, filetype = "GTiff", overwrite = T)
  
  #data quality check!
  
  
  print(paste0("creation of min max temperature future rasters for the month ",name_of_the_month[i]," completed"))
  
}  








# reference_raster <- rastmin
# 
# rm(rastmin)
# rm(rastmax)
# 
# reference_raster
# 
# # Import reference raster (The cassava host raster)
# host_uga <- raster("Land_cassava_raster_Africa50KM.tif")
# 
# # check the resolution and the number of lattice
# host_uga




############################################################
#                                                          #
#  ---->  will deal with the current scenario later  <---- #
#                                                          #
############################################################
# 
# 
# # illustration for the resampling technique
# #r <- raster(nrow=3, ncol=3)
# #values(r) <- 1:ncell(r)
# #s <- raster(nrow=10, ncol=10)
# #s <- resample(r, s, method='bilinear')
# 
# ###########################################
# #Step 3 : current climate scenario - 2020 #
# ###########################################
# 
# dir_tmax <- as.character("D:/climate data/Tmax_2020_2021_WorldClim")
# 
# dir_tmin <- as.character("D:/climate data/Tmin_2020_2021_WorldClim")
# 
# filename_prefix_tmin   <- as.character("/wc2.1_2.5m_tmin_")
# 
# filename_prefix_tmax   <- as.character("/wc2.1_2.5m_tmax_")
# 
# suffix_1_to_9 <- as.character("-0")
# 
# suffix_10_to_12 <- as.character("-")
# 
# # initialization of an empty vector for Tmin and Tmax
# names.Tmin <- rep("",times = 12)
# 
# names.Tmax <- rep("",times = 12)
# 
# #years<-c("2020","2021")
# 
# #for (y in years){
# 
# y <- as.character("2020")
# 
# for(i in 1:12){
#   
#   if(i <= 9) {
#     names.Tmin[i] <-  as.character(paste(dir_tmin,filename_prefix_tmin,y,suffix_1_to_9,i,sep=""))
#     names.Tmax[i] <-  as.character(paste(dir_tmax,filename_prefix_tmax,y,suffix_1_to_9,i,sep=""))
#   }
#   
#   if(i > 9) {
#     names.Tmin[i] <-  as.character(paste(dir_tmin,filename_prefix_tmin,y,suffix_10_to_12,i,sep=""))
#     names.Tmax[i] <-  as.character(paste(dir_tmax,filename_prefix_tmax,y,suffix_10_to_12,i,sep=""))
#   }
#   
# }
# 
# #}
# 
# #start, create folders in your workspace:
# if (!dir.exists("present_geospatial"))dir.create(path = "present_geospatial")
# 
# #start, create folders in your workspace for Africa
# if (!dir.exists("present_geospatial/Africa"))dir.create(path = "present_geospatial/Africa")
# 
# #start, create folders in your workspace for Tmin
# if (!dir.exists("present_geospatial/Africa/tempMin"))dir.create(path = "present_geospatial/Africa/tempMin")
# 
# #start, create folders in your workspace for Tmax
# if (!dir.exists("present_geospatial/Africa/tempMax"))dir.create(path = "present_geospatial/Africa/tempMax")
# 
# dir_tmin <- as.character("present_geospatial/Africa/tempMin")
# 
# dir_tmax <- as.character("present_geospatial/Africa/tempMax")
# 
# name_of_the_month <- c('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')
# 
# data(wrld_simpl)
# SPDF <- subset(wrld_simpl, NAME=="Africa")
# 
# for(i in 1:12){
#   
#   # load raster in an R object called 'rast'
#   rastmin0 <- raster(paste(names.Tmin[i],".tif",sep = ""))
#   rastmax0 <- raster(paste(names.Tmax[i],".tif",sep = ""))
#   
#   ## crop
#   rastmin1  <- raster::crop(rastmin0 , extent(SPDF))
#   rastmax1  <- raster::crop(rastmax0 , extent(SPDF))
#   
#   rastmin2  <- raster::mask(rastmin1, SPDF)
#   rastmax2  <- raster::mask(rastmax1, SPDF)
#   
#   # Resample the raster to have same characteristics is the reference_raster
#   rastmin <- raster::resample(reference_raster, rastmin2, method='bilinear')
#   rastmax <- raster::resample(reference_raster, rastmax2, method='bilinear')
#   
#   # make the memory free
#   rm(rastmin1)
#   rm(rastmin2)
#   rm(rastmax1)
#   rm(rastmax2)
#   
#   # 
#   rastmin <- setMinMax(rastmin)
#   rastmax <- setMinMax(rastmax)
#   
#   # be aware that the original data are multiplied by 10 to reduce decimals and save the memory
#   rastmin <- rastmin/10
#   rastmax <- rastmax/10
#   
#   #spatial projection
#   projection(rastmin) <- crs(rastmin0) # May not be needed
#   projection(rastmax) <- crs(rastmax0) # May not be needed
#   
#   # make the memroy free
#   rm(rastmax0)
#   rm(rastmin0)
#   
#   directory.tmin <- paste(dir_tmin,"/tmin_2020_",as.character(i),".tif", sep = "")
#   directory.tmax <- paste(dir_tmax,"/tmax_2020_",as.character(i),".tif", sep = "")
#   
#   # save raster
#   terra::writeRaster(rastmin,directory.tmin, filetype = "GTiff", overwrite = T)
#   terra::writeRaster(rastmax,directory.tmax, filetype = "GTiff", overwrite = T)
#   
#   #data quality check!
#   
#   
#   print(paste0("creation of min max temperature raster for the month ",name_of_the_month[i]," completed"))
#   
# }  
# 
# 
# ###########################################
# #Step 3 : current climate scenario - 2021 #
# ###########################################
# 
# dir_tmax <- as.character("D:/climate data/Tmax_2020_2021_WorldClim")
# 
# dir_tmin <- as.character("D:/climate data/Tmin_2020_2021_WorldClim")
# 
# filename_prefix_tmin   <- as.character("/wc2.1_2.5m_tmin_")
# 
# filename_prefix_tmax   <- as.character("/wc2.1_2.5m_tmax_")
# 
# suffix_1_to_9 <- as.character("-0")
# 
# suffix_10_to_12 <- as.character("-")
# 
# # initialization of an empty vector for Tmin and Tmax
# names.Tmin <- rep("",times = 24)
# 
# names.Tmax <- rep("",times = 24)
# 
# #years<-c("2020","2021")
# 
# #for (y in years){
# 
# y <- as.character("2021")
# 
# for(i in 1:12){
#   
#   if(i <= 9) {
#     names.Tmin[i] <-  as.character(paste(dir_tmin,filename_prefix_tmin,y,suffix_1_to_9,i,sep=""))
#     names.Tmax[i] <-  as.character(paste(dir_tmax,filename_prefix_tmax,y,suffix_1_to_9,i,sep=""))
#   }
#   
#   if(i > 9) {
#     names.Tmin[i] <-  as.character(paste(dir_tmin,filename_prefix_tmin,y,suffix_10_to_12,i,sep=""))
#     names.Tmax[i] <-  as.character(paste(dir_tmax,filename_prefix_tmax,y,suffix_10_to_12,i,sep=""))
#   }
#   
# }
# 
# #}
# 
# #start, create folders in your workspace:
# if (!dir.exists("present_geospatial"))dir.create(path = "present_geospatial")
# 
# #start, create folders in your workspace for Africa
# if (!dir.exists("present_geospatial/Africa"))dir.create(path = "present_geospatial/Africa")
# 
# #start, create folders in your workspace for Tmin
# if (!dir.exists("present_geospatial/Africa/tempMin"))dir.create(path = "present_geospatial/Africa/tempMin")
# 
# #start, create folders in your workspace for Tmax
# if (!dir.exists("present_geospatial/Africa/tempMax"))dir.create(path = "present_geospatial/Africa/tempMax")
# 
# dir_tmin <- as.character("present_geospatial/Africa/tempMin")
# 
# dir_tmax <- as.character("present_geospatial/Africa/tempMax")
# 
# name_of_the_month <- c('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')
# 
# data(wrld_simpl)
# SPDF <- subset(wrld_simpl, NAME=="Africa")
# 
# for(i in 1:12){
#   
#   # load raster in an R object called 'rast'
#   rastmin0 <- raster(paste(names.Tmin[i],".tif",sep = ""))
#   rastmax0 <- raster(paste(names.Tmax[i],".tif",sep = ""))
#   
#   ## crop
#   rastmin1  <- raster::crop(rastmin0 , extent(SPDF))
#   rastmax1  <- raster::crop(rastmax0 , extent(SPDF))
#   
#   rastmin2  <- raster::mask(rastmin1, SPDF)
#   rastmax2  <- raster::mask(rastmax1, SPDF)
#   
#   # Resample the raster to have same characteristics is the reference_raster
#   rastmin <- raster::resample(reference_raster, rastmin2, method='bilinear')
#   rastmax <- raster::resample(reference_raster, rastmax2, method='bilinear')
#   
#   # make the memory free
#   rm(rastmin1)
#   rm(rastmin2)
#   rm(rastmax1)
#   rm(rastmax2)
#   
#   # 
#   rastmin <- setMinMax(rastmin)
#   rastmax <- setMinMax(rastmax)
#   
#   # be aware that the original data are multiplied by 10 to reduce decimals and save the memory
#   rastmin <- rastmin/10
#   rastmax <- rastmax/10
#   
#   #spatial projection
#   projection(rastmin) <- crs(rastmin0) # May not be needed
#   projection(rastmax) <- crs(rastmax0) # May not be needed
#   
#   # make the memroy free
#   rm(rastmax0)
#   rm(rastmin0)
#   
#   directory.tmin <- paste(dir_tmin,"/tmin_2021_",as.character(i),".tif", sep = "")
#   directory.tmax <- paste(dir_tmax,"/tmax_2021_",as.character(i),".tif", sep = "")
#   
#   # save raster
#   terra::writeRaster(rastmin,directory.tmin, filetype = "GTiff", overwrite = T)
#   terra::writeRaster(rastmax,directory.tmax, filetype = "GTiff", overwrite = T)
#   
#   #data quality check!
#   
#   
#   print(paste0("creation of min max temperature raster for the month ",name_of_the_month[i]," completed"))
#   
# }  
