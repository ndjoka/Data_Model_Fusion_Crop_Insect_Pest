rm(list=ls())
#clear the console
cat("\014")


library(raster)
library(countrycode)
library(sf)
library(ggplot2)
library(tidyr)
library(latex2exp)
library(RColorBrewer)
library(latticeExtra)
library(rnaturalearth)
library(rnaturalearthdata)
library(rnaturalearthhires)
library(rnaturalearth)
library(viridis)
library(raster)
library(countrycode)
library(sf)
library(renv)
library(maptools)
library(tidyverse)
library(terra)
library(geodata)
library(stars)
#library(rdgal)


#renv::init(repos = "https://packagemanager.posit.co/cran/2023-10-13")
#install.packages("maptools")
#https://cran.r-project.org/bin/windows/Rtools/rtools44/files/rtools44-aarch64-6335-6327.exe
#library(devtools)
#devtools::install_github("ropensci/rnaturalearthhires")

# Import reference raster (The cassava host raster)
host_Africa <- raster("Cassava Plant and Vector Location  Data/host.tif")

# Check the quality
plot(host_Africa)

# check the resolution and the number of lattice
host_Africa

#Note
#resolution.pixel  = 1  : approx 1km^2   
#resolution.pixel  = 2  : approx 4km^2
#resolution.pixel  = 3  : approx 9km^2
#resolution.pixel  = 4  : approx 16km^2
#resolution.pixel  = 5  : approx 25km^2 <- This run in a country
#resolution.pixel  = 6  : approx 36km^2
#resolution.pixel  = 7  : approx 49km^2
#resolution.pixel  = 8  : approx 64km^2
#resolution.pixel  = 9  : approx 91km^2  
#resolution.pixel  = 10 : approx 100km^2 <- This run in a reasonable time for a region / continent
# ...... etc

resolution.pixel <- 25

#Aggregate from 30 arc-seconds resolution to 2.5 arc-minutes (150 arc-seconds)(factor = 5)

host_red <- raster::aggregate(host_Africa, fact = resolution.pixel, fun=mean, expand=TRUE, na.rm=TRUE)

host_red

plot(host_red)

terra::writeRaster(host_red , "Land_cassava_raster_Africa_25KM.tif", filetype = "GTiff", overwrite = T)

pol <- raster::rasterToPolygons(host_red, fun=function(x){x>0 & x<=1} , n=4, na.rm=TRUE ) 

plot(pol)

elev <- raster("elev.tif")

plot(elev)

elev_0 <- raster::crop(elev, extent(pol))

elev_casav <- mask(elev_0, pol)

elev_casav

plot(elev_casav)


# Import reference raster (The cassava host raster)
rescaled_raster <- raster("past_geospatial/Africa/tempMax/tmax1.tif")

# Check the quality
plot(rescaled_raster)

# check the resolution and the number of lattice
rescaled_raster


# Import reference raster (The cassava host raster)
ref_raster <- raster("Land_cassava_raster_Africa_100KM.tif")

# Check the quality
plot(ref_raster)

# check the resolution and the number of lattice
ref_raster




# ------> to do the same for a specific country see bellow <------

###########################
## Land data for Uganda  ##
########################### 
# 
# ## Example SpatialPolygonsDataFrame
# data(wrld_simpl)
# SPDF <- subset(wrld_simpl, NAME=="Uganda")
# 
# ## crop and mask
# uganda_cassava_0 <- raster::crop(host_Africa, extent(SPDF))
# uganda_cassava <- mask(uganda_cassava_0, SPDF)
# 
# plot(uganda_cassava)
# 
# uganda_cassava
# 
# resolution.pixel <- 15
# 
# uganda_cassava_15KMsqr <- raster::aggregate(uganda_cassava, fact = resolution.pixel, fun=mean, expand=TRUE, na.rm=TRUE)
# 
# uganda_cassava_15KMsqr
# 
# plot(uganda_cassava_15KMsqr)
# 
# terra::writeRaster(uganda_cassava_15KMsqr , "Land_cassava_raster_Uganda15KM.tif", filetype = "GTiff", overwrite = T)
# 
# 
###########################
## Land data for Nigeria ##
###########################
# 
# 
# ## Example SpatialPolygonsDataFrame
# data(wrld_simpl)
# SPDF <- subset(wrld_simpl, NAME=="Nigeria")
# 
# SPDF
# 
# ## crop and mask
# nigeria_cassava_0 <- raster::crop(host_Africa, extent(SPDF))
# nigeria_cassava <- mask(nigeria_cassava_0, SPDF)
# 
# plot(nigeria_cassava)
# 
# nigeria_cassava
# 
# resolution.pixel <- 25
# 
# nigeria_cassava_25KMsqr <- raster::aggregate(nigeria_cassava, fact = resolution.pixel, fun=mean, expand=TRUE, na.rm=TRUE)
# 
# nigeria_cassava_25KMsqr
# 
# plot(nigeria_cassava_25KMsqr)
# 
# terra::writeRaster(nigeria_cassava_25KMsqr , "Land_cassava_raster_nigeria25KM.tif", filetype = "GTiff", overwrite = T)
