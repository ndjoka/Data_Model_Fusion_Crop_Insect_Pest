rm(list=ls())
#clear the console
cat("\014")

library(raster)
library(countrycode)
library(sf)
library(ggplot2)
library(tidyr)
library(latex2exp)
library(RColorBrewer)
library(latticeExtra)
library(rnaturalearth)
library(rnaturalearthdata)
library(rnaturalearthhires)
library(rnaturalearth)
library(viridis)
library(raster)
library(countrycode)
library(sf)
library(renv)
library(maptools)
library(tidyverse)
library(terra)
library(geodata)
library(stars)
#library(rdgal)


#renv::init(repos = "https://packagemanager.posit.co/cran/2023-10-13")
#install.packages("maptools")
#https://cran.r-project.org/bin/windows/Rtools/rtools44/files/rtools44-aarch64-6335-6327.exe
#library(devtools)
#devtools::install_github("ropensci/rnaturalearthhires")

# Import reference raster (The cassava host raster)
host_Africa <- raster("Cassava Plant and Vector Location  Data/host.tif")

# Check the quality
plot(host_Africa)

# check the resolution and the number of lattice
host_Africa

#Note
#resolution.pixel  = 1  : approx 1km^2   
#resolution.pixel  = 2  : approx 4km^2
#resolution.pixel  = 3  : approx 9km^2
#resolution.pixel  = 4  : approx 16km^2
#resolution.pixel  = 5  : approx 25km^2 <- This run in a country
#resolution.pixel  = 6  : approx 36km^2
#resolution.pixel  = 7  : approx 49km^2
#resolution.pixel  = 8  : approx 64km^2
#resolution.pixel  = 9  : approx 91km^2  
#resolution.pixel  = 10 : approx 100km^2 <- This run in a reasonable time for a region / continent
# ...... etc

resolution.pixel <- 9

#Aggregate from 30 arc-seconds resolution to 2.5 arc-minutes (150 arc-seconds)(factor = 5)

# host_red <- raster::aggregate(host_Africa, fact = resolution.pixel, fun=mean, expand=TRUE, na.rm=TRUE)
# 
# host_red
# 
# plot(host_red)
# 
# terra::writeRaster(host_red , "Land_cassava_raster_Africa_25KM.tif", filetype = "GTiff", overwrite = T)
# 
# pol <- raster::rasterToPolygons(host_red, fun=function(x){x>0 & x<=1} , n=4, na.rm=TRUE ) 
# 
# plot(pol)
# 
# elev <- raster("elev.tif")
# 
# plot(elev)
# 
# elev_0 <- raster::crop(elev, extent(pol))
# 
# elev_casav <- mask(elev_0, pol)
# 
# elev_casav
# 
# plot(elev_casav)
# 
# 
# # Import reference raster (The cassava host raster)
# rescaled_raster <- raster("past_geospatial/Africa/tempMax/tmax1.tif")
# 
# # Check the quality
# plot(rescaled_raster)
# 
# # check the resolution and the number of lattice
# rescaled_raster
# 
# 
# # Import reference raster (The cassava host raster)
# ref_raster <- raster("Land_cassava_raster_Africa_100KM.tif")
# 
# # Check the quality
# plot(ref_raster)
# 
# # check the resolution and the number of lattice
# ref_raster



library(rnaturalearth)
library(sf)

# The official name in the dataset is "United Republic of Tanzania"
tanzania <- ne_countries(country = "United Republic of Tanzania", 
                         scale = "medium", 
                         returnclass = "sf")

# Plot to verify
plot(st_geometry(tanzania), main = "Tanzania")

## crop and mask
tanzania_cassava_0 <- raster::crop(host_Africa, extent(tanzania))

tanzania_cassava <- mask(tanzania_cassava_0, tanzania)

plot(tanzania_cassava)

tanzania_cassava

tanzania_cassava_10KMsqr <- raster::aggregate(tanzania_cassava, fact = resolution.pixel, fun=mean, expand=TRUE, na.rm=TRUE)

tanzania_cassava_10KMsqr

plot(tanzania_cassava_10KMsqr)

terra::writeRaster(tanzania_cassava_10KMsqr , "Land_cassava_raster_tanzania_pop_9KM.tif", filetype = "GTiff", overwrite = T)

