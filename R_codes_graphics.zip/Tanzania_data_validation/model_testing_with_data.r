#clear the memory
rm(list=ls())

#clear the console
cat("\014")

#2014
#Total Number of generations = 5
#Average generation length   = 69.00  

#2015
#Total Number of generations =   4
#Average generation length   =   87.00 

########################################
# Import the Monthly Adult field data  #
########################################

Field.Adult <- read.table("Tanzania_data.txt", sep = "\t", header = TRUE, dec =".")


#############################################
# Import the Monthly Adult simulation data  #
#############################################

# 2014
Sim.Adult.2014 <- read.table("Best_month_PopulationDensity_TANZ2014_Cassava.txt", 
                             sep = "\t", header = FALSE, dec =".")

# 2015
Sim.Adult.2015 <- read.table("Best_month_PopulationDensity_TANZ2015_Cassava.txt", 
                             sep = "\t", header = FALSE, dec =".")

Sim.Adult.2014 <- as.data.frame(Sim.Adult.2014)

Sim.Adult.2015 <- as.data.frame(Sim.Adult.2015)

Sim.Adult.2014

Sim.Adult.2015

library(plotly)

#x <- c('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December')

x <- c('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12')

y1 <-  Field.Adult$season_2014[]


y2 <- c( 6,
         21,
         33,
         42,
         57,
         69,
         32,
         38,
         31,
         33,
         15,
         0)

data <- data.frame(x, y1, y2)

#The default order will be alphabetized unless specified as below:
data$x <- factor(data$x, levels = data[["x"]])

fig <- plot_ly(data, x = ~x, y = ~y1, 
               type = 'bar', 
               name = 'Observed',
               marker = list(color = 'rgb(192,192,192)'))

fig <- fig %>% add_trace(y = ~y2, 
                         name = 'Simulated', 
                         marker = list(color = 'rgb(0,0,0)'))

fig <- fig %>% layout(xaxis = list(title = "",tickangle = 0),#tickangle = -45 for long text
                      yaxis = list(title = ""),
                      margin = list(b = 100),
                      barmode = 'group')


fig <- fig %>% layout(title = "12 January 2014 - 20 January 2015 ",
                      barmode = 'group',
                      xaxis = list(title = "Month", 
                                   titlefont = list(
                                  size = 30,
                                  color = 'rgb(0, 0, 0)'),
                                   tickfont = list(
                                     size = 25,
                                     color = 'rgb(0, 0, 0)')),
                      yaxis = list(title = "Adult Population size (#)",
                                   titlefont = list(
                                     size = 30,
                                     color = 'rgb(0, 0, 0)'),
                                   tickfont = list(
                                     size = 25,
                                     color = 'rgb(0, 0, 0)')))

fig <- fig %>% layout(showlegend = TRUE, legend = list(font = list(size = 30)))

fig


###############################  compare      ###########################################

library(plotly)

#x <- c('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December')

y1 <-  Field.Adult$season_2015[]


y2 <- c(19,
        41,
        97,
        90,
        58,
        46,
        42,
        33,
        27,
        36,
        0,
        0)

data <- data.frame(x, y1, y2)

#The default order will be alphabetized unless specified as below:
data$x <- factor(data$x, levels = data[["x"]])

fig <- plot_ly(data, x = ~x, y = ~y1, 
               type = 'bar', 
               name = 'Observed',
               marker = list(color = 'rgb(192,192,192)'))

fig <- fig %>% add_trace(y = ~y2, 
                         name = 'Simulated', 
                         marker = list(color = 'rgb(0,0,0)'))

fig <- fig %>% layout(xaxis = list(title = "",tickangle = 0),#tickangle = -45 for long text
                      yaxis = list(title = ""),
                      margin = list(b = 100),
                      barmode = 'group')


fig <- fig %>% layout(title = "16 March 2015 - 19 March 2016 ",
                      barmode = 'group',
                      xaxis = list(title = "Month", 
                                   titlefont = list(
                                     size = 30,
                                     color = 'rgb(0, 0, 0)'),
                                   tickfont = list(
                                     size = 25,
                                     color = 'rgb(0, 0, 0)')),
                      yaxis = list(title = "Adult Population size (#)",
                                   titlefont = list(
                                     size = 30,
                                     color = 'rgb(0, 0, 0)'),
                                   tickfont = list(
                                     size = 25,
                                     color = 'rgb(0, 0, 0)')))

fig <- fig %>% layout(showlegend = TRUE, legend = list(font = list(size = 30)))

fig


####################################################################
#####  Model Precision Assessment With Linear Regression ###########
####################################################################

reg.conf.intervals <- function(x, y) {
  
  n <- length(y) # Find length of y to use as sample size
  
  lm.out <- lm(y ~ x) # Fit linear model
  
  newx = seq(min(x), max(x), by = 0.05 )
  
  conf_interval <- predict(lm.out, 
                           newdata=data.frame(x=newx), 
                           interval="confidence",
                           level = 0.95)
  
  #plot(x, y, xlab="x", ylab="y", main="Regression")
  #abline(lm.out, col="lightblue")
  #lines(newx, conf_interval[,2], col="blue", lty=2)
  #lines(newx, conf_interval[,3], col="blue", lty=2)
  
  
  # Collect the computed confidence bands into a data.frame and name the colums
  bands <- data.frame(cbind(conf_interval[,2], conf_interval[,3], newx))
  colnames(bands) <- c('Lower.Confidence.Band', 'Upper.Confidence.Band','newx')
  
  return(bands)
  
}


lin.reg.stats <- function(x, y) {
  
  lm.r<-lm(y ~ x)
  
  R_squared_linear <- summary(lm.r)$r.squared
  
  p_Value_linear   <- anova(lm.r)$'Pr(>F)'[1]
  
  AIC_linear       <- AIC(lm.r)
  
  statistics <- data.frame(cbind(R_squared_linear, p_Value_linear, AIC_linear))
  
  colnames(statistics) <- c('R.Sqr', 'p.val' , 'AIC' )
  
  return(statistics)
  
}

################  2014 ######################

x.adult.2014 <- Field.Adult$season_2014[]

y.adult.2014 <- c( 6,
                   21,
                   33,
                   42,
                   57,
                   69,
                   32,
                   38,
                   31,
                   33,
                   15,
                   0) 


lm.r.2014 <-lm(y.adult.2014 ~ x.adult.2014)
conf.intervals.2014 <- reg.conf.intervals(x.adult.2014, y.adult.2014)
reg.stats.2014 <- lin.reg.stats(x.adult.2014, y.adult.2014)

lm.r.2014
reg.stats.2014

#tiff(file="Figure5.tiff",
#     width=935, height=665, res=100)

# Nymph plot
bottom <- 5.1
left   <- 4.1
top    <- 4.1
right  <- 2.1

par(mar = c(bottom+0.8, left + 0.7, top, right)) #increase left margin with 0.7


min_data = min( min(x.adult.2014) , min(y.adult.2014) )

max_data = max( max(x.adult.2014) , max(y.adult.2014) )

plot(x.adult.2014,
     y.adult.2014,
     pch = 19,
     col = "blue",
     cex = 3,
     ylab= "Simulated",
     xlab= "Observed",
     xlim =c(min_data,max_data),
     ylim =c(min_data,max_data),
     cex.lab=2,
     cex.axis=2,
     frame.plot = FALSE,
     axes=FALSE,
     font.lab=2)

lines(x.adult.2014, predict(lm.r.2014, data.frame(x.adult.2014 = x.adult.2014 )),
      col = 'black', lty = 1, lwd = 4)

lines( conf.intervals.2014$newx, 
       conf.intervals.2014$Lower.Confidence.Band,
       col = 'red', lty = 2, lwd = 6)

lines(conf.intervals.2014$newx, 
      conf.intervals.2014$Upper.Confidence.Band, 
      col = 'red', lty = 2, lwd = 6)


lines(min_data:max_data, 
      min_data:max_data, 
      col = 'darkgrey', lty = 3, lwd = 5)

axis(side = 1, lwd = 3 ,cex.lab=1.5, cex.axis =2, font.lab=2)

axis(side = 2, lwd = 3 ,cex.lab=1.5, cex.axis =2, font.lab=2)

#dev.off()


################  2015 ######################

x.adult.2015 <- Field.Adult$season_2015[]

y.adult.2015 <- c(19,
                  41,
                  97,
                  90,
                  58,
                  46,
                  42,
                  33,
                  27,
                  36,
                  0,
                  0) 


lm.r.2015 <-lm(y.adult.2015 ~ x.adult.2015)
conf.intervals.2015 <- reg.conf.intervals(x.adult.2015, y.adult.2015)
reg.stats.2015 <- lin.reg.stats(x.adult.2015, y.adult.2015)

lm.r.2015
reg.stats.2015

#tiff(file="Figure5.tiff",
#     width=935, height=665, res=100)

# Nymph plot
bottom <- 5.1
left   <- 4.1
top    <- 4.1
right  <- 2.1

par(mar = c(bottom+0.8, left + 0.7, top, right)) #increase left margin with 0.7


min_data = min( min(x.adult.2015) , min(y.adult.2015) )

max_data = max( max(x.adult.2015) , max(y.adult.2015) )

#max(x.adult.2015)
#max(y.adult.2015)

plot(x.adult.2015,
     y.adult.2015,
     pch = 19,
     col = "blue",
     cex = 3,
     ylab= "Simulated",
     xlab= "Observed",
     xlim =c(min_data,max_data+10),
     ylim =c(min_data,max_data+10),
     cex.lab=2,
     cex.axis=2,
     frame.plot = FALSE,
     axes=FALSE,
     font.lab=2)

lines(x.adult.2015, predict(lm.r.2015, data.frame(x.adult.2015 = x.adult.2015 )),
      col = 'black', lty = 1, lwd = 4)

lines( conf.intervals.2015$newx, 
       conf.intervals.2015$Lower.Confidence.Band,
       col = 'red', lty = 2, lwd = 6)

lines(conf.intervals.2015$newx, 
      conf.intervals.2015$Upper.Confidence.Band, 
      col = 'red', lty = 2, lwd = 6)


lines(0:max_data+10, 
      0:max_data+10, 
      col = 'darkgrey', lty = 3, lwd = 5)

axis(side = 1, lwd = 3 ,cex.lab=1.5, cex.axis =2, font.lab=2)

axis(side = 2, lwd = 3 ,cex.lab=1.5, cex.axis =2, font.lab=2)

#dev.off()


####  statistics ########

summary(lm.r.2014)
head(reg.stats.2014)

summary(lm.r.2015)
head(reg.stats.2015)
